#!/bin/sh

for dep in make cmake gcc
do
  if ! command -v $dep >/dev/null 2>&1
  then
    echo "Missing $dep (try 'sudo apt install $dep' on Ubuntu/Debian)"
    exit 1
  fi
done

git clone https://github.com/intel/SGX-TDX-DCAP-QuoteVerificationLibrary.git -b v1.1.8886
cd SGX-TDX-DCAP-QuoteVerificationLibrary/Src
./release -DBUILD_TESTS=OFF
cd ../..
echo "-- Done building QVL --"
